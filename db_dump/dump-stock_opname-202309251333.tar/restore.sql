--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.23
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stock_opname;
--
-- Name: stock_opname; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stock_opname WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE stock_opname OWNER TO postgres;

\connect stock_opname

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class (
    id_class integer NOT NULL,
    id_department integer,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.class OWNER TO postgres;

--
-- Name: class_id_class_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.class_id_class_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.class_id_class_seq OWNER TO postgres;

--
-- Name: class_id_class_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.class_id_class_seq OWNED BY public.class.id_class;


--
-- Name: cut_off; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cut_off (
    id_cut_off integer NOT NULL,
    cut_off_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    description character varying(255)
);


ALTER TABLE public.cut_off OWNER TO postgres;

--
-- Name: cut_off_id_cut_off_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cut_off_id_cut_off_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cut_off_id_cut_off_seq OWNER TO postgres;

--
-- Name: cut_off_id_cut_off_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cut_off_id_cut_off_seq OWNED BY public.cut_off.id_cut_off;


--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    id_department integer NOT NULL,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: department_id_department_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.department_id_department_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.department_id_department_seq OWNER TO postgres;

--
-- Name: department_id_department_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.department_id_department_seq OWNED BY public.department.id_department;


--
-- Name: goods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goods (
    id_goods integer NOT NULL,
    id_sub_class integer,
    id_uom integer,
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.goods OWNER TO postgres;

--
-- Name: goods_id_goods_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.goods_id_goods_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goods_id_goods_seq OWNER TO postgres;

--
-- Name: goods_id_goods_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.goods_id_goods_seq OWNED BY public.goods.id_goods;


--
-- Name: location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location (
    id_location integer NOT NULL,
    id_sub_regional integer,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.location OWNER TO postgres;

--
-- Name: location_id_location_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.location_id_location_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.location_id_location_seq OWNER TO postgres;

--
-- Name: location_id_location_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.location_id_location_seq OWNED BY public.location.id_location;


--
-- Name: regional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regional (
    id_regional integer NOT NULL,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.regional OWNER TO postgres;

--
-- Name: regional_id_regional_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.regional_id_regional_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.regional_id_regional_seq OWNER TO postgres;

--
-- Name: regional_id_regional_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.regional_id_regional_seq OWNED BY public.regional.id_regional;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock (
    id_stock integer NOT NULL,
    id_location integer,
    id_goods integer,
    quantity integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.stock OWNER TO postgres;

--
-- Name: stock_id_stock_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_id_stock_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_id_stock_seq OWNER TO postgres;

--
-- Name: stock_id_stock_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_id_stock_seq OWNED BY public.stock.id_stock;


--
-- Name: stock_opname; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_opname (
    id_cut_off integer,
    id_stock integer,
    quantity integer,
    real_quantity integer
);


ALTER TABLE public.stock_opname OWNER TO postgres;

--
-- Name: sub_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_class (
    id_sub_class integer NOT NULL,
    id_class integer,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.sub_class OWNER TO postgres;

--
-- Name: sub_class_id_sub_class_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sub_class_id_sub_class_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sub_class_id_sub_class_seq OWNER TO postgres;

--
-- Name: sub_class_id_sub_class_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sub_class_id_sub_class_seq OWNED BY public.sub_class.id_sub_class;


--
-- Name: sub_regional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_regional (
    id_sub_regional integer NOT NULL,
    id_regional integer,
    name character varying(100),
    description character varying(255)
);


ALTER TABLE public.sub_regional OWNER TO postgres;

--
-- Name: sub_regional_id_sub_regional_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sub_regional_id_sub_regional_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sub_regional_id_sub_regional_seq OWNER TO postgres;

--
-- Name: sub_regional_id_sub_regional_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sub_regional_id_sub_regional_seq OWNED BY public.sub_regional.id_sub_regional;


--
-- Name: uom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uom (
    id_uom integer NOT NULL,
    name character varying(100),
    description character varying(255),
    abbreviation character varying(100)
);


ALTER TABLE public.uom OWNER TO postgres;

--
-- Name: uom_id_uom_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.uom_id_uom_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uom_id_uom_seq OWNER TO postgres;

--
-- Name: uom_id_uom_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.uom_id_uom_seq OWNED BY public.uom.id_uom;


--
-- Name: verify; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verify (
    id_cut_off integer,
    id_stock integer,
    description character varying(500)
);


ALTER TABLE public.verify OWNER TO postgres;

--
-- Name: class id_class; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class ALTER COLUMN id_class SET DEFAULT nextval('public.class_id_class_seq'::regclass);


--
-- Name: cut_off id_cut_off; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cut_off ALTER COLUMN id_cut_off SET DEFAULT nextval('public.cut_off_id_cut_off_seq'::regclass);


--
-- Name: department id_department; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department ALTER COLUMN id_department SET DEFAULT nextval('public.department_id_department_seq'::regclass);


--
-- Name: goods id_goods; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods ALTER COLUMN id_goods SET DEFAULT nextval('public.goods_id_goods_seq'::regclass);


--
-- Name: location id_location; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location ALTER COLUMN id_location SET DEFAULT nextval('public.location_id_location_seq'::regclass);


--
-- Name: regional id_regional; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regional ALTER COLUMN id_regional SET DEFAULT nextval('public.regional_id_regional_seq'::regclass);


--
-- Name: stock id_stock; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock ALTER COLUMN id_stock SET DEFAULT nextval('public.stock_id_stock_seq'::regclass);


--
-- Name: sub_class id_sub_class; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_class ALTER COLUMN id_sub_class SET DEFAULT nextval('public.sub_class_id_sub_class_seq'::regclass);


--
-- Name: sub_regional id_sub_regional; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_regional ALTER COLUMN id_sub_regional SET DEFAULT nextval('public.sub_regional_id_sub_regional_seq'::regclass);


--
-- Name: uom id_uom; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uom ALTER COLUMN id_uom SET DEFAULT nextval('public.uom_id_uom_seq'::regclass);


--
-- Data for Name: class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class (id_class, id_department, name, description) FROM stdin;
\.
COPY public.class (id_class, id_department, name, description) FROM '$$PATH$$/2910.dat';

--
-- Data for Name: cut_off; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cut_off (id_cut_off, cut_off_date, description) FROM stdin;
\.
COPY public.cut_off (id_cut_off, cut_off_date, description) FROM '$$PATH$$/2920.dat';

--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (id_department, name, description) FROM stdin;
\.
COPY public.department (id_department, name, description) FROM '$$PATH$$/2908.dat';

--
-- Data for Name: goods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goods (id_goods, id_sub_class, id_uom, name, description) FROM stdin;
\.
COPY public.goods (id_goods, id_sub_class, id_uom, name, description) FROM '$$PATH$$/2916.dat';

--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location (id_location, id_sub_regional, name, description) FROM stdin;
\.
COPY public.location (id_location, id_sub_regional, name, description) FROM '$$PATH$$/2906.dat';

--
-- Data for Name: regional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regional (id_regional, name, description) FROM stdin;
\.
COPY public.regional (id_regional, name, description) FROM '$$PATH$$/2902.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock (id_stock, id_location, id_goods, quantity, created_at) FROM stdin;
\.
COPY public.stock (id_stock, id_location, id_goods, quantity, created_at) FROM '$$PATH$$/2918.dat';

--
-- Data for Name: stock_opname; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_opname (id_cut_off, id_stock, quantity, real_quantity) FROM stdin;
\.
COPY public.stock_opname (id_cut_off, id_stock, quantity, real_quantity) FROM '$$PATH$$/2921.dat';

--
-- Data for Name: sub_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_class (id_sub_class, id_class, name, description) FROM stdin;
\.
COPY public.sub_class (id_sub_class, id_class, name, description) FROM '$$PATH$$/2912.dat';

--
-- Data for Name: sub_regional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_regional (id_sub_regional, id_regional, name, description) FROM stdin;
\.
COPY public.sub_regional (id_sub_regional, id_regional, name, description) FROM '$$PATH$$/2904.dat';

--
-- Data for Name: uom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uom (id_uom, name, description, abbreviation) FROM stdin;
\.
COPY public.uom (id_uom, name, description, abbreviation) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: verify; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verify (id_cut_off, id_stock, description) FROM stdin;
\.
COPY public.verify (id_cut_off, id_stock, description) FROM '$$PATH$$/2922.dat';

--
-- Name: class_id_class_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_id_class_seq', 16, true);


--
-- Name: cut_off_id_cut_off_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cut_off_id_cut_off_seq', 3, true);


--
-- Name: department_id_department_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_id_department_seq', 3, true);


--
-- Name: goods_id_goods_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.goods_id_goods_seq', 78, true);


--
-- Name: location_id_location_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.location_id_location_seq', 37, true);


--
-- Name: regional_id_regional_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.regional_id_regional_seq', 3, true);


--
-- Name: stock_id_stock_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_id_stock_seq', 2106, true);


--
-- Name: sub_class_id_sub_class_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sub_class_id_sub_class_seq', 14, true);


--
-- Name: sub_regional_id_sub_regional_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sub_regional_id_sub_regional_seq', 9, true);


--
-- Name: uom_id_uom_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.uom_id_uom_seq', 10, true);


--
-- Name: class class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class
    ADD CONSTRAINT class_pkey PRIMARY KEY (id_class);


--
-- Name: cut_off cut_off_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cut_off
    ADD CONSTRAINT cut_off_pkey PRIMARY KEY (id_cut_off);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id_department);


--
-- Name: goods goods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_pkey PRIMARY KEY (id_goods);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id_location);


--
-- Name: regional regional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regional
    ADD CONSTRAINT regional_pkey PRIMARY KEY (id_regional);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id_stock);


--
-- Name: sub_class sub_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_class
    ADD CONSTRAINT sub_class_pkey PRIMARY KEY (id_sub_class);


--
-- Name: sub_regional sub_regional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_regional
    ADD CONSTRAINT sub_regional_pkey PRIMARY KEY (id_sub_regional);


--
-- Name: uom uom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uom
    ADD CONSTRAINT uom_pkey PRIMARY KEY (id_uom);


--
-- Name: class class_id_class_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class
    ADD CONSTRAINT class_id_class_fkey1 FOREIGN KEY (id_department) REFERENCES public.department(id_department);


--
-- Name: goods goods_id_uom_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_id_uom_fkey FOREIGN KEY (id_uom) REFERENCES public.uom(id_uom);


--
-- Name: goods goods_id_uom_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_id_uom_fkey1 FOREIGN KEY (id_uom) REFERENCES public.uom(id_uom);


--
-- Name: location location_id_location_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_id_location_fkey FOREIGN KEY (id_sub_regional) REFERENCES public.sub_regional(id_sub_regional);


--
-- Name: stock stock_id_goods_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_id_goods_fkey FOREIGN KEY (id_goods) REFERENCES public.goods(id_goods);


--
-- Name: stock stock_id_location_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_id_location_fkey FOREIGN KEY (id_location) REFERENCES public.location(id_location);


--
-- Name: stock_opname stock_opname_id_cut_off_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_opname
    ADD CONSTRAINT stock_opname_id_cut_off_fkey FOREIGN KEY (id_cut_off) REFERENCES public.cut_off(id_cut_off);


--
-- Name: stock_opname stock_opname_id_stock_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_opname
    ADD CONSTRAINT stock_opname_id_stock_fkey FOREIGN KEY (id_stock) REFERENCES public.stock(id_stock);


--
-- Name: sub_class sub_class_id_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_class
    ADD CONSTRAINT sub_class_id_class_fkey FOREIGN KEY (id_class) REFERENCES public.class(id_class);


--
-- Name: sub_class sub_class_id_class_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_class
    ADD CONSTRAINT sub_class_id_class_fkey1 FOREIGN KEY (id_class) REFERENCES public.class(id_class);


--
-- Name: sub_regional sub_regional_id_regional_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_regional
    ADD CONSTRAINT sub_regional_id_regional_fkey FOREIGN KEY (id_regional) REFERENCES public.regional(id_regional);


--
-- Name: sub_regional sub_regional_id_regional_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_regional
    ADD CONSTRAINT sub_regional_id_regional_fkey1 FOREIGN KEY (id_regional) REFERENCES public.regional(id_regional);


--
-- Name: verify verify_id_cut_off_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify
    ADD CONSTRAINT verify_id_cut_off_fkey FOREIGN KEY (id_cut_off) REFERENCES public.cut_off(id_cut_off);


--
-- Name: verify verify_id_stock_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify
    ADD CONSTRAINT verify_id_stock_fkey FOREIGN KEY (id_stock) REFERENCES public.stock(id_stock);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

